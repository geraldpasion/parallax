//Pretty photo
jQuery(function($) {
	$("a[rel^='prettyPhoto']").prettyPhoto({
		theme: 'dark_rounded',
		keyboard_shortcuts: true,
		social_tools: false
	});
});