

### 1.3.5 - 10/12/2014

 Changes: 


 * This fixes #43 , color for active menu item
 * Fix for scrolling menu when has dropdown
 * This fixes #51 : Aliniere componente Our Focus
 * This fixes #41 - preloader
 * This fixes #42 submenu issue
 * This fixes #50 - Footer issue
 * This Fixes #45 - Links not working on mobile
 * This fixes #39 Widget Colors issue
 * This fixes small issues of the footer on mobile


### 1.2.7 - 13/11/2014

 Changes: 


 * Fix for update system.


### 1.2.6 - 13/11/2014

 Changes: 


 * Fixed clients widget
 * Template for blog


### 1.2.4 - 12/11/2014

 Changes: 


 * Fixed spelling mistake on portofolio
 * Fixed sections order in customizer


### 1.2.2 - 12/11/2014

 Changes: 


 * Fixed menu


### 1.2.1 - 12/11/2014

 Changes: 


 * This fixes #21, full width template
 * This fixes #24, woocommerce support
 * This fixes #23 wpml compatible
 * This fixes #18, our team issue with team widget disordered
 * This fixes #14, pricing section
 * This fixes #29, new tab for clients widget link
 * This fixes #28, full width page and full width static homepage
 * This fixes #27
 * This fixes #31, fixed header on archive page
 * This fixes #25 google map section
 * Fixed #22, footer display for small number of items
 * Fixed footer and started to add css for woocommerce
 * Fixed footer
 * This fixes #24 , and added default value to google map in customizer
 * Center our team and our focus sections, changed sections order and other improvments
 * Fixed menu smooth scroll
 * This fixes #26, subscribe section
 * Fixed subscribe section


### 1.0.6 - 29/10/2014

 Changes: 


 * this fixes #17, #12 and #11
 * This fixes #7, custom field for email address and editable button for contact form
 * Update to 1.0.5
 * This fixes #13 footer textareas instead of texts with icons
 * fixed icons issue
 * fixed fatal error
 * fixed footer icons image
 * fixed default icons footer


### 1.0.4 - 25/10/2014

 Changes: 


 * Update style.css


### 1.0.3 - 25/10/2014

 Changes: 


 * Delete README.md
 * Rename README.txt to README.md


### 1.0.3 - 24/10/2014

 Changes: 


 * close #8, close #6, close #5
 * Close #9   bottom ribbon fiex
 * Fixed sections order
 * Update to 1.0.3 version
 * Improved code for sections order


### 1.0.2 - 23/10/2014

 Changes: 


 * Started to add colors option in customizer
 * Finished to add colors changeing options in customizer
 * Updated customizer with panels and other improvements
 * Improved customizer panels


### 1.0 - 17/10/2014

 Changes: 


 * Fist version of Zerif Pro
 * Small fixes, upload image in customizer
 * Update functions.php
 * Small fixes - remove preloader on other pages the frontapge, our focus section images and colors, portofolio number of items, about us section
 * Small style fixes
 * Added screenshot
 * Update style.css
 * Responsive issues solved
 * some fixes responsive css
